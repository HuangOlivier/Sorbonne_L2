public class TestTrianglePascal {
    public static void main (String [] args) {
        TrianglePascal t1 = new TrianglePascal (10);
        t1.remplirTriangle ();
        System.out.println(t1);
    }
}