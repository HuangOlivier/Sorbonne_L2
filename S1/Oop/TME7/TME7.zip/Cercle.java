public class Cercle extends Ellipse {
	public Cercle (double a, double b) {
		super(a, b);
	}
}
