public class Boa extends AnimauxSansPattes {
	
	public Boa (String nom, int age) {
		super(nom, age);
	}
	
	public String crier() {
		return String.format ("Boa crie");
	}
}
