public class Carre extends Rectangle {
	public Carre (double largeur) {
		super(largeur, largeur);
	}
}
